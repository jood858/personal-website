# My Personal Website 🌐

This is a simple personal website built using HTML and CSS.  
It includes a homepage with basic info and a clean design.

## 🔧 Technologies Used
- HTML
- CSS

## 📁 Files
- `index.html`: main page
- `style.css`: styles
- `README.md`: project info

## 📸 Preview
You can open `index.html` in your browser to see the site.

## 📌 Author
Made by **Jood Awad** ✨
